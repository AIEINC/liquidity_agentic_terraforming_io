## Quickstart for Termux
1. pkg install python
2. pip install -r requirements.txt
3. python agent.py