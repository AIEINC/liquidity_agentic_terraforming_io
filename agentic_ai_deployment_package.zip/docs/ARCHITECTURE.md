@startuml
!define Rectangle(x) class x << (R,#FFAAAA) >>
@enduml