# v5.0 (2024-03-20)  
### Added  
- Helm chart for Kubernetes deployments  
- DigitalOcean Terraform automation  
- SBOM generation via Syft  

### Security  
- GPG + Sigstore signing pipeline  
- Immutable audit logging  
